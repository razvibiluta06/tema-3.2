# Aplicații JavaScript - Laborator

Acest repository conține aplicații JavaScript realizate în cadrul laboratorului.  

## Conținut:

1. `fibonacci.html` – Afișează toate numerele Fibonacci dintr-un interval `[n1, n2]`.
2. `inversare_litere.html` – Inversează literele unui string: a -> z, b -> y etc.
3. `armstrong.html` – Afișează toate numerele Armstrong dintr-un interval `[n1, n2]`.
